# Doane CCLA OpenMPI in C++ Module

This repository contains the code artifacts for the Doane Center for Computing in the Liberal Arts (CCLA) OpenMPI in C++ course module. The code is organized into five directories.

`1-hello`: directory containing the "Hello from other processors" example

`2-pi`: directory containing the Monte Carlo Pi estimation code

`3-burning-ship`: directory containing the Burning Ship fractal code

`4-deadlock`: directory containing the two deadlock examples

`5-assignment`: directory containing skeleton code for the final programming assignment, the parallel bucket sort